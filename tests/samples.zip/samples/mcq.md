::: question
ID: Q-MCQ-001
Type: MCQ
MCQ Type: single
::: stem
# What is the capital of France?
Select the correct option from the list below.
::: mcq-config
Orientation: vertical
Type: default
::: options
::: option [id=op1] [correct]
Paris
::: option [id=op2]
London
::: option [id=op3]
Berlin
::: option [id=op4]
Madrid
:::
