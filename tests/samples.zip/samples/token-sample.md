::: question
ID: 48
QuestionID: Token-Sample_1
Type: token_highlight
Tags: [id=6974835ae95132000173a4c7] Tag 1, [id=6974835ae95132000173a4c8] Tag 2
:::

::: mcq-config
Orientation: vertical
MCQ Type: default
:::

::: options
::: option id=6974835ae95132000173a4bd
:::
::: option id=6974835ae95132000173a4be
:::
::: option id=6974835ae95132000173a4bf
:::
::: option id=6974835ae95132000173a4c0
:::
:::

::: secondary-options
::: option id=1
True
:::
::: option id=2
False
:::
:::

::: matrix-config
Multiple Response: false
:::

::: matrix-mapping
1: 1
2: 1
3: 2
4: 1
:::

::: stem
This is a Token Highlight Question. Below this line the Question stem is in 2 column Layout.

::: columns [1fr, 1fr]
This is the part of the Question Stem in the Left column which has $70 %$% width. $70$ is written in Latex. All numbers, formulas, units, expression, math will all be written in Latex with proper formatting like Fraction $\frac{a}{b}$ is incorrect while $\dfrac{a}{b}$ is correct.

This entire sentence is in bold

This entire sentence is in bold and italics<br>
<br>
This is a table with 2 rows and 3 columns:<br>

| R1C1 | R1C2 | R1C3 |
|------|------|------|
| R2C1 | R2C2 | R2C3 |


<br>
Below is an image: 
![This is the Alt Text for US NG G7 L2 image 026](https://d2lhxh95t9lwdp.cloudfront.net/US_NG_G7_L2_image_026)
=== COL
This is the right column content.<br>
Below is a Latex Rendered Visual in the right column.

```latex[image="https://d37a7zdiv6xmqa.cloudfront.net/media/Token-Sample-5_10001.png",width=313,height=157]
\documentclass[tikz, border=10pt]{standalone}
\usepackage{fontspec}
\setmainfont{Latin Modern Roman}
\usepackage{tikz}
\usetikzlibrary{shapes.symbols, positioning}
\usepackage{xcolor}
\usepackage{bm}

\definecolor{K5_Indigo}{HTML}{2b0c81}
\definecolor{K5_Blue}{HTML}{539df7}
\definecolor{K5_Red}{HTML}{ff2500}
\definecolor{K5_Black}{HTML}{000000}
\definecolor{K5_White}{HTML}{ffffff}

\begin{document}
    \begin{tikzpicture}
        % Board Background
        \fill[K5_Black] (0,0) rectangle (4,2);
        \draw[K5_Indigo, line width=2pt] (0,0) rectangle (4,2);
        
        % Dividers
        \draw[K5_White!30] (2,0.2) -- (2,1.8);
        
        % Team Labels
        \node[text=K5_White, font=\sffamily\tiny\bfseries] at (1, 1.6) {TEAM A};
        \node[text=K5_White, font=\sffamily\tiny\bfseries] at (3, 1.6) {TEAM B};
        
        % Scores
        \node[text=K5_Blue, font=\sffamily\LARGE\bfseries] at (1, 0.9) {$286$};
        \node[text=K5_Red, font=\sffamily\LARGE\bfseries] at (3, 0.9) {$354$};
        
        % Logic Tags
        \node[anchor=west, text=K5_Blue, font=\sffamily\tiny\bfseries, draw=K5_Blue, rounded corners=1pt] at (4.2, 1.3) {TOTAL (+)};
        \node[anchor=west, text=K5_Red, font=\sffamily\tiny\bfseries, draw=K5_Red, rounded corners=1pt] at (4.2, 0.7) {GAP ($-$ )};
    \end{tikzpicture}
\end{document}
```
:::
:::

::: classification-config
Type: default
Duplicate Responses: false
:::

::: matchds-stimuluslist
- [id=6974835ae95132000173a4c1][_id=1] 
- [id=6974835ae95132000173a4c2][_id=2] 
- [id=6974835ae95132000173a4c3][_id=3] 
:::

::: matchds-possibleresponses
- [id=6974835ae95132000173a4c4][_id=1] 
- [id=6974835ae95132000173a4c5][_id=2] 
- [id=6974835ae95132000173a4c6][_id=3] 
:::

::: token-config
Token Type: word
:::

::: token-text
She reads a book.

A book is read by her.

The meal was cooked by the chef.

The chef cooked the meal.
:::

::: token-answers
0, 2, 5, 8
:::

::: solution
Here we keep a detailed Step by Step Solution with proper spacing with line and paragraph breaks.

We make use of Latex rendered visuals.

We use 1 column layout

We use formatting options

We keep all math (numbers, equations, fractions, formulas etc) in latex
:::

::: hint
Here we keep a simple 2 liner with proper spacing with line and paragraph breaks.

We use 1 column layout

We use formatting options

We keep all math (numbers, equations, fractions, formulas etc) in latex
:::
