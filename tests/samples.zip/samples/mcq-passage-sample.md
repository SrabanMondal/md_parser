::: question

ID: 11
QuestionID: MAMCQ-Passage-Sample
Type: MCQ
Tags: [id=6960e7451bce46000111d92d] Tag 1, [id=6960e7451bce46000111d92e] Tag 2

::: stem
This is the Question stem for the Passage.<br><br>In this soliloquy, what is Hamlet contemplating? 
:::

::: passage
This is the passage :<br><br>$\dfrac{a}{b}$ is fraction written in latex

Below is a bulleted list:

- Bullet point 1
- Bullet point 2

Below is a numbered list:

1. pointer number 1
2. pointer number 2

**This sentence is in bold**

***This sentence is in italics***

Below is an image

![US NG G7 L2 image 026](https://d2lhxh95t9lwdp.cloudfront.net/US_NG_G7_L2_image_026){width=400,height=175}<br>To be, or not to be, that is the question:
Whether 'tis nobler in the mind to suffer
The slings and arrows of outrageous fortune,
Or to take arms against a sea of troubles
And by opposing end them. To die—to sleep,
No more; and by a sleep to say we end
The heart-ache and the thousand natural shocks
That flesh is heir to: 'tis a consummation
Devoutly to be wish'd. To die, to sleep;
To sleep, perchance to dream—ay, there's the rub...

- From William Shakespeare's Hamlet

::latex[code="\documentclass[tikz,border=10pt]{standalone}\n\usepackage{fontspec}\n\usepackage{tikz}\n\usetikzlibrary{arrows.meta}\n\usepackage{xcolor}\n\usepackage{bm}\n\setmainfont{Latin Modern Roman}\n\definecolor{K5_Indigo}{HTML}{2b0c81}\n\definecolor{K5_Red}{HTML}{ff2500}\n\definecolor{K5_Blue}{HTML}{539df7}\n\n\begin{document}\n    \begin{tikzpicture}[font=\sffamily, scale=0.8]\n        % Linear Stairs (Path 1)\n        \draw[K5_Indigo, line width=2pt] (0,0) -- (1,0) -- (1,1) -- (2,1) -- (2,2) -- (3,2) -- (3,3) -- (4,3);\n        \node[K5_Indigo] at (0.5,-0.5) {$2$};\n        \node[K5_Indigo] at (1.5,0.5) {$4$};\n        \node[K5_Indigo] at (2.5,1.5) {$6$};\n        \node[K5_Indigo] at (3.5,2.5) {$8$};\n        \node[K5_Indigo, anchor=west] at (4,3) {Linear};\n\n        % Exponential Curve (Path 2)\n        \draw[K5_Red, line width=2pt, ->, >=Stealth] (5,0) .. controls (6,0.5) and (7,2) .. (8,8);\n        \fill[K5_Red] (5,0) circle (3pt) node[right=5pt] {$2$};\n        \fill[K5_Red] (5.8,0.6) circle (3pt) node[right=5pt] {$4$};\n        \fill[K5_Red] (6.8,2.4) circle (3pt) node[right=5pt] {$8$};\n        \fill[K5_Red] (7.8,6.5) circle (3pt) node[right=5pt] {$16$};\n        \node[K5_Red, anchor=west] at (8,8) {Exponential};\n    \end{tikzpicture}\n\end{document}",image="https://d37a7zdiv6xmqa.cloudfront.net/media/MAMCQ-Passage-Sample_10001.png",width=331,height=284]::
:::

::: mcq-config
Type: passage
Orientation: vertical
:::

::: options

::: option [id=6960e7451bce46000111d923]
Whether to avenge his father's death or forgive his uncle.
:::

::: option [id=6960e7451bce46000111d924][correct]
The choice between living with suffering or ending his life.<br>::latex[code="\documentclass[tikz,border=10pt]{standalone}\n\usepackage{fontspec}\n\usepackage{tikz}\n\usetikzlibrary{arrows.meta}\n\usepackage{xcolor}\n\usepackage{bm}\n\setmainfont{Latin Modern Roman}\n\definecolor{K5_Indigo}{HTML}{2b0c81}\n\definecolor{K5_Red}{HTML}{ff2500}\n\definecolor{K5_Blue}{HTML}{539df7}\n\n\begin{document}\n    \begin{tikzpicture}[font=\sffamily, scale=0.8]\n        % Linear Stairs (Path 1)\n        \draw[K5_Indigo, line width=2pt] (0,0) -- (1,0) -- (1,1) -- (2,1) -- (2,2) -- (3,2) -- (3,3) -- (4,3);\n        \node[K5_Indigo] at (0.5,-0.5) {$2$};\n        \node[K5_Indigo] at (1.5,0.5) {$4$};\n        \node[K5_Indigo] at (2.5,1.5) {$6$};\n        \node[K5_Indigo] at (3.5,2.5) {$8$};\n        \node[K5_Indigo, anchor=west] at (4,3) {Linear};\n\n        % Exponential Curve (Path 2)\n        \draw[K5_Red, line width=2pt, ->, >=Stealth] (5,0) .. controls (6,0.5) and (7,2) .. (8,8);\n        \fill[K5_Red] (5,0) circle (3pt) node[right=5pt] {$2$};\n        \fill[K5_Red] (5.8,0.6) circle (3pt) node[right=5pt] {$4$};\n        \fill[K5_Red] (6.8,2.4) circle (3pt) node[right=5pt] {$8$};\n        \fill[K5_Red] (7.8,6.5) circle (3pt) node[right=5pt] {$16$};\n        \node[K5_Red, anchor=west] at (8,8) {Exponential};\n    \end{tikzpicture}\n\end{document}",image="https://d37a7zdiv6xmqa.cloudfront.net/media/MAMCQ-Passage-Sample_10002.png",width=416,height=167]::
:::

::: option [id=6960e7451bce46000111d925]
Deciding whether to go to war or seek a peaceful resolution.<br>![US NG G7 L2 image 026](https://d2lhxh95t9lwdp.cloudfront.net/US_NG_G7_L2_image_026){width=400,height=175}
:::

::: option [id=6960e7451bce46000111d926][correct]
The meaning of dreams and their connection to reality.
:::

:::

::: solution
Here we keep a simple 2 liner with proper spacing with line and paragraph breaks.<br>We use 1 column layout<br>We use formatting options<br>We keep all math (numbers, equations, fractions, formulas etc) in latex
:::

::: hint
Analyze the very first line: 'To be, or not to be, that is the question'. What fundamental choice does this phrase represent?
:::

:::
