::: question

ID: 15
QuestionID: ChoiceMatrix-Images-Sample
Type: MCQ
Tags: [id=6974835ae95132000173a4c7] Tag 1, [id=6974835ae95132000173a4c8] Tag 2

::: stem

This is a Question . Below this line the Question stem is in 2 column Layout

- Step 1
- Step 2

::: columns [70%, 30%]

This is the part of the Question Stem.<br><br>**This entire sentence is in bold**

***This entire sentence is in bold and italics***<br><br>This is a table with 2 rows and 3 columns:<br>

| R1C1 | R1C2 | R1C3 |
|------|------|------|
| R2C1 | R2C2 | R2C3 |

Below is an image: <br><br>![image](https://d37a7zdiv6xmqa.cloudfront.net/media/ChoiceMatrix-Images-Sample_10002.png){width=800,height=350,mediaId=105}

=== COL

This is the right column content.<br>Below is a Latex Rendered Visual in the right column.

```latex[image="https://d37a7zdiv6xmqa.cloudfront.net/media/ChoiceMatrix-Images-Sample_10003.png",width=296,height=172]
\documentclass[tikz, border=10pt]{standalone}
\usepackage{fontspec}
\setmainfont{Latin Modern Roman}
\usepackage{tikz}
\usetikzlibrary{shapes.symbols, positioning}
\usepackage{xcolor}
\usepackage{bm}

\definecolor{K5_Indigo}{HTML}{2b0c81}
\definecolor{K5_Blue}{HTML}{539df7}
\definecolor{K5_Red}{HTML}{ff2500}
\definecolor{K5_Black}{HTML}{000000}
\definecolor{K5_White}{HTML}{ffffff}

\begin{document}
    \begin{tikzpicture}
        % Board Background
        \fill[K5_Black] (0,0) rectangle (4,2);
        \draw[K5_Indigo, line width=2pt] (0,0) rectangle (4,2);
        
        % Dividers
        \draw[K5_White!30] (2,0.2) -- (2,1.8);
        
        % Team Labels
        \node[text=K5_White, font=\sffamily\tiny\bfseries] at (1, 1.6) {TEAM A};
        \node[text=K5_White, font=\sffamily\tiny\bfseries] at (3, 1.6) {TEAM B};
        
        % Scores
        \node[text=K5_Blue, font=\sffamily\LARGE\bfseries] at (1, 0.9) {$286$};
        \node[text=K5_Red, font=\sffamily\LARGE\bfseries] at (3, 0.9) {$354$};
        
        % Logic Tags
        \node[anchor=west, text=K5_Blue, font=\sffamily\tiny\bfseries, draw=K5_Blue, rounded corners=1pt] at (4.2, 1.3) {TOTAL (+)};
        \node[anchor=west, text=K5_Red, font=\sffamily\tiny\bfseries, draw=K5_Red, rounded corners=1pt] at (4.2, 0.7) {GAP ($-$ )};
    \end{tikzpicture}
\end{document}
```

:::

:::

::: mcq-config
Type: matrix
Orientation: horizontal
:::

::: options

::: option [id=6968de1caace54000102e397][_id=row1]
**Whale**
:::

::: option [id=6968de1caace54000102e398][_id=row2]
Snake

![image](https://d37a7zdiv6xmqa.cloudfront.net/media/ChoiceMatrix-Sample_10002.png){width=225,height=225,mediaId=25}
:::

::: option [id=6968de1caace54000102e399][_id=row3]
Dolphin

::latex[code="\documentclass[tikz,border=10pt]{standalone}\n\n% --- Required Packages ---\n\usepackage{fontspec}\n\usepackage{tikz}\n\usetikzlibrary{positioning, arrows.meta}\n\usepackage{xcolor}\n\usepackage{bm}\n\n% --- Font Setting ---\n\setmainfont{Latin Modern Roman}\n\n% --- K-5 Color Palette ---\n\definecolor{K5_Red}{HTML}{ff2500}\n\definecolor{K5_Indigo}{HTML}{2b0c81}\n\definecolor{K5_White}{HTML}{ffffff}\n\n\begin{document}\n    \begin{tikzpicture}[\n        font=\sffamily,\n        node distance=1cm,\n        % Styles\n        button/.style={\n            circle, \n            minimum size=2.5cm, \n            fill=K5_Red, \n            text=K5_White, \n            font=\fontsize{80}{88}\selectfont\bfseries, \n            inner sep=0pt\n        },\n        label_text/.style={\n            text=K5_Indigo, \n            font=\fontsize{50}{58}\selectfont\bfseries, \n            anchor=east\n        },\n        value_text/.style={\n            text=K5_Indigo, \n            font=\fontsize{50}{58}\selectfont\bfseries, \n            anchor=west\n        }\n    ]\n\n        % Central Button\n        \node[button] (btn) {-};\n\n        % Left Label\n        \node[label_text, left=1cm of btn] {Negative Integer};\n\n        % Right Value\n        \node[value_text, right=1cm of btn] {-1};\n\n    \end{tikzpicture}\n\end{document}\n",image="https://d37a7zdiv6xmqa.cloudfront.net/media/ChoiceMatrix-Images-Sample_10004.png",width=157,height=87]::
:::

::: option [id=6968de1caace54000102e39a][_id=row4]
Crocodile<br><br>$\dfrac{a}{b}$
:::

:::

::: matrix-config
Multiple Response: true
:::

::: secondary-options

::: option [_id=col1]
Mammal<br><br>$\dfrac{a}{b}$

::latex[code="\documentclass[tikz,border=10pt]{standalone}\n\n% --- Required Packages ---\n\usepackage{fontspec}\n\usepackage{tikz}\n\usetikzlibrary{positioning, arrows.meta}\n\usepackage{xcolor}\n\usepackage{bm}\n\n% --- Font Setting ---\n\setmainfont{Latin Modern Roman}\n\n% --- K-5 Color Palette ---\n\definecolor{K5_Red}{HTML}{ff2500}\n\definecolor{K5_Indigo}{HTML}{2b0c81}\n\definecolor{K5_White}{HTML}{ffffff}\n\n\begin{document}\n    \begin{tikzpicture}[\n        font=\sffamily,\n        node distance=1cm,\n        % Styles\n        button/.style={\n            circle, \n            minimum size=2.5cm, \n            fill=K5_Red, \n            text=K5_White, \n            font=\fontsize{80}{88}\selectfont\bfseries, \n            inner sep=0pt\n        },\n        label_text/.style={\n            text=K5_Indigo, \n            font=\fontsize{50}{58}\selectfont\bfseries, \n            anchor=east\n        },\n        value_text/.style={\n            text=K5_Indigo, \n            font=\fontsize{50}{58}\selectfont\bfseries, \n            anchor=west\n        }\n    ]\n\n        % Central Button\n        \node[button] (btn) {-};\n\n        % Left Label\n        \node[label_text, left=1cm of btn] {Negative Integer};\n\n        % Right Value\n        \node[value_text, right=1cm of btn] {-1};\n\n    \end{tikzpicture}\n\end{document}\n",image="https://d37a7zdiv6xmqa.cloudfront.net/media/ChoiceMatrix-Images-Sample_10005.png",width=432,height=162]::
:::

::: option [_id=col2]
Reptile

![image](https://d37a7zdiv6xmqa.cloudfront.net/media/ChoiceMatrix-Images-Sample_10006.png){width=800,height=350,mediaId=109}

:::

:::

::: matrix-mapping
row1: col2, col1
row2: col1
row3: col2
row4: col1, col2
:::

::: solution
Here we keep a detailed Step by Step Solution with proper spacing with line and paragraph breaks.<br>We make use of Latex rendered visuals.<br>We use 1 column layout<br>We use formatting options<br>We keep all math (numbers, equations, fractions, formulas etc) in latex
:::

::: hint
Here we keep a simple 2 liner with proper spacing with line and paragraph breaks.<br>We use 1 column layout<br>We use formatting options<br>We keep all math (numbers, equations, fractions, formulas etc) in latex
:::

:::
