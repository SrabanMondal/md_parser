::: question

ID: 50
QuestionID: Sample-FIB-2
Type: fill_in_the_gap
Tags: [id=6974cf5ee95132000173a508] Tag 1, [id=6974cf5ee95132000173a509] Tag 2

::: stem
This is a Classification Question . Below this line the Question stem is in 2 column Layout

::: columns [70%, 30%]

This is the part of the Question Stem in the Left column which has $70$ % width. $70$ is written in Latex. All numbers, formulas, units, expression, math will all be written in Latex with proper formatting like Fraction $\frac{a}{b}$ is incorrect while $\dfrac{a}{b}$ is correct.<br><br>**This entire sentence is in bold**

***This entire sentence is in bold and italics***<br><br>This is a table with 2 rows and 3 columns:<br>

| R1C1 | R1C2 | R1C3 |
|------|------|------|
| R2C1 | R2C2 | R2C3 |

Below is an image: <br>![image](https://d37a7zdiv6xmqa.cloudfront.net/media/Sample-FIB-2_10001.png){width=800,height=350,mediaId=100}

This is Blank 1 and its answer is::fitg[answer="Answer 1",width=100]:: <br>The width of the blank is 100px

=== COL

This is the right column content.<br>Below is a Latex Rendered Visual in the right column.<br>::latex[code="\documentclass[tikz, border=10pt]{standalone}\n\usepackage{fontspec}\n\setmainfont{Latin Modern Roman}\n\usepackage{tikz}\n\usetikzlibrary{shapes.symbols, positioning}\n\usepackage{xcolor}\n\usepackage{bm}\n\n\definecolor{K5_Indigo}{HTML}{2b0c81}\n\definecolor{K5_Blue}{HTML}{539df7}\n\definecolor{K5_Red}{HTML}{ff2500}\n\definecolor{K5_Black}{HTML}{000000}\n\definecolor{K5_White}{HTML}{ffffff}\n\n\begin{document}\n    \begin{tikzpicture}\n        % Board Background\n        \fill[K5_Black] (0,0) rectangle (4,2);\n        \draw[K5_Indigo, line width=2pt] (0,0) rectangle (4,2);\n        \n        % Dividers\n        \draw[K5_White!30] (2,0.2) -- (2,1.8);\n        \n        % Team Labels\n        \node[text=K5_White, font=\sffamily\tiny\bfseries] at (1, 1.6) {TEAM A};\n        \node[text=K5_White, font=\sffamily\tiny\bfseries] at (3, 1.6) {TEAM B};\n        \n        % Scores\n        \node[text=K5_Blue, font=\sffamily\LARGE\bfseries] at (1, 0.9) {$286$};\n        \node[text=K5_Red, font=\sffamily\LARGE\bfseries] at (3, 0.9) {$354$};\n        \n        % Logic Tags\n        \node[anchor=west, text=K5_Blue, font=\sffamily\tiny\bfseries, draw=K5_Blue, rounded corners=1pt] at (4.2, 1.3) {TOTAL (+)};\n        \node[anchor=west, text=K5_Red, font=\sffamily\tiny\bfseries, draw=K5_Red, rounded corners=1pt] at (4.2, 0.7) {GAP ($-$ )};\n    \end{tikzpicture}\n\end{document}",image="https://d37a7zdiv6xmqa.cloudfront.net/media/Sample-FIB-2_10002.png",width=276,height=220]::

This is Blank 2 and its answer is ::fitg[answer="Answer 2",width=200]:: <br>The width of the blank is 200px

:::

:::

::: solution
Here we keep a detailed Step by Step Solution with proper spacing with line and paragraph breaks.<br>We make use of Latex rendered visuals.<br>We use 1 column layout<br>We use formatting options<br>We keep all math (numbers, equations, fractions, formulas etc) in latex
:::

::: hint
Here we keep a simple 2 liner with proper spacing with line and paragraph breaks.<br>We use 1 column layout<br>We use formatting options<br>We keep all math (numbers, equations, fractions, formulas etc) in latex
:::

:::
