::: question
ID: new
QuestionID: MatchList-Sample-3
Type: classification
Tags: [id=697480dde95132000173a483] Tag 1, [id=697480dde95132000173a484] Tag 2
Difficulty Level: 0.3
Discrimination Level: 0.5
:::

::: mcq-config
Orientation: vertical
MCQ Type: default
:::

::: options
::: option id=697480dde95132000173a46e
:::
::: option id=697480dde95132000173a46f
:::
::: option id=697480dde95132000173a470
:::
::: option id=697480dde95132000173a471
:::
:::

::: secondary-options
::: option id=1
True
:::
::: option id=2
False
:::
:::

::: matrix-config
Multiple Response: false
:::

::: matrix-mapping
1: 1
2: 1
3: 2
4: 1
:::

::: stem
This is a Match List question.  Below this line the Question stem is in 2 column Layout.

::: columns [1fr, 1fr]
This is the part of the Question Stem in the Left column which has $70 %$% width. $70$ is written in Latex. All numbers, formulas, units, expression, math will all be written in Latex with proper formatting like Fraction $\frac{a}{b}$ is incorrect while $\dfrac{a}{b}$ is correct.

- this is simple text
- *this is bold*

<br>
<br>
This is a table with 2 rows and 3 columns:<br>

| R1C1 | R1C2 | R1C3 |
|------|------|------|
| R2C1 | R2C2 | R2C3 |

=== COL
This is the right column content.<br>
Below is a Latex Rendered Visual in the right column.

```latex[image="https://d37a7zdiv6xmqa.cloudfront.net/media/MatchList-Sample-3_10001.png",width=334,height=218]
\documentclass[tikz, border=10pt]{standalone}
\usepackage{fontspec}
\setmainfont{Latin Modern Roman}
\usepackage{tikz}
\usetikzlibrary{shapes.symbols, positioning}
\usepackage{xcolor}
\usepackage{bm}

\definecolor{K5_Indigo}{HTML}{2b0c81}
\definecolor{K5_Blue}{HTML}{539df7}
\definecolor{K5_Red}{HTML}{ff2500}
\definecolor{K5_Black}{HTML}{000000}
\definecolor{K5_White}{HTML}{ffffff}

\begin{document}
    \begin{tikzpicture}
        % Board Background
        \fill[K5_Black] (0,0) rectangle (4,2);
        \draw[K5_Indigo, line width=2pt] (0,0) rectangle (4,2);
        
        % Dividers
        \draw[K5_White!30] (2,0.2) -- (2,1.8);
        
        % Team Labels
        \node[text=K5_White, font=\sffamily\tiny\bfseries] at (1, 1.6) {TEAM A};
        \node[text=K5_White, font=\sffamily\tiny\bfseries] at (3, 1.6) {TEAM B};
        
        % Scores
        \node[text=K5_Blue, font=\sffamily\LARGE\bfseries] at (1, 0.9) {$286$};
        \node[text=K5_Red, font=\sffamily\LARGE\bfseries] at (3, 0.9) {$354$};
        
        % Logic Tags
        \node[anchor=west, text=K5_Blue, font=\sffamily\tiny\bfseries, draw=K5_Blue, rounded corners=1pt] at (4.2, 1.3) {TOTAL (+)};
        \node[anchor=west, text=K5_Red, font=\sffamily\tiny\bfseries, draw=K5_Red, rounded corners=1pt] at (4.2, 0.7) {GAP ($-$ )};
    \end{tikzpicture}
\end{document}
```

Below is an image: 
![This is the Alt Text for US NG G7 L2 image 026](https://d2lhxh95t9lwdp.cloudfront.net/US_NG_G7_L2_image_026){width=299,height=119}

this is another list

1. **This is another text**
2. ***This is second text***
:::
:::

::: classification-config
Type: match
Duplicate Responses: false
:::

::: classification-column-names
- [id=697480dde95132000173a472] Column 1
- [id=697480dde95132000173a473] Column 2
:::

::: classification-row-names
- [id=697480dde95132000173a474] Row 1
- [id=697480dde95132000173a475] Row 2
:::

::: classification-possible-responses
- [id=697480dde95132000173a476] Response 1
:::

::: matchds-stimuluslist
- [id=697480dde95132000173a477][_id=1] Category Alpha<br><br>![This is the Alt Text for US NG G7 L2 image 026](https://d2lhxh95t9lwdp.cloudfront.net/US_NG_G7_L2_image_026)
- [id=697480dde95132000173a478][_id=2] Category Beta
- [id=697480dde95132000173a479][_id=3] Category Gamma
- [id=697480dde95132000173a47a][_id=4ec6f8fb-efd0-4666-96ba-5959cb1d97f9] Category Delta<br>
:::latex[code="\documentclass[tikz, border=10pt]{standalone}\n\usepackage{fontspec}\n\setmainfont{Latin Modern Roman}\n\usepackage{tikz}\n\usetikzlibrary{shapes.symbols, positioning}\n\usepackage{xcolor}\n\usepackage{bm}\n\n\definecolor{K5_Indigo}{HTML}{2b0c81}\n\definecolor{K5_Blue}{HTML}{539df7}\n\definecolor{K5_Red}{HTML}{ff2500}\n\definecolor{K5_Black}{HTML}{000000}\n\definecolor{K5_White}{HTML}{ffffff}\n\n\begin{document}\n    \begin{tikzpicture}\n        % Board Background\n        \fill[K5_Black] (0,0) rectangle (4,2);\n        \draw[K5_Indigo, line width=2pt] (0,0) rectangle (4,2);\n        \n        % Dividers\n        \draw[K5_White!30] (2,0.2) -- (2,1.8);\n        \n        % Team Labels\n        \node[text=K5_White, font=\sffamily\tiny\bfseries] at (1, 1.6) {TEAM A};\n        \node[text=K5_White, font=\sffamily\tiny\bfseries] at (3, 1.6) {TEAM B};\n        \n        % Scores\n        \node[text=K5_Blue, font=\sffamily\LARGE\bfseries] at (1, 0.9) {$286$};\n        \node[text=K5_Red, font=\sffamily\LARGE\bfseries] at (3, 0.9) {$354$};\n        \n        % Logic Tags\n        \node[anchor=west, text=K5_Blue, font=\sffamily\tiny\bfseries, draw=K5_Blue, rounded corners=1pt] at (4.2, 1.3) {TOTAL (+)};\n        \node[anchor=west, text=K5_Red, font=\sffamily\tiny\bfseries, draw=K5_Red, rounded corners=1pt] at (4.2, 0.7) {GAP ($-$ )};\n    \end{tikzpicture}\n\end{document}",image="https://d37a7zdiv6xmqa.cloudfront.net/media/MatchList-Sample-3_10002.png",width=268,height=122]::
- [id=697480dde95132000173a47b][_id=153a445a-969a-450d-b8f0-75b4ffe3e2f8] Type A (Organic)
- [id=697480dde95132000173a47c][_id=c77b83be-5567-4f64-97b8-f1f9b1cc6f15] Type B (Synthetic)<br>
| R1C1 | R1C2 | R1C3 |
|------|------|------|
| R2C1 | R2C2 | R2C3 |
:::

::: matchds-possibleresponses
- [id=697480dde95132000173a47d][_id=1] 1
- [id=697480dde95132000173a47e][_id=2] <br>![This is the Alt Text for US NG G7 L2 image 026](https://d2lhxh95t9lwdp.cloudfront.net/US_NG_G7_L2_image_026)
- [id=697480dde95132000173a47f][_id=3] <br>::latex[code="\documentclass[tikz, border=10pt]{standalone}\n\usepackage{fontspec}\n\setmainfont{Latin Modern Roman}\n\usepackage{tikz}\n\usetikzlibrary{shapes.symbols, positioning}\n\usepackage{xcolor}\n\usepackage{bm}\n\n\definecolor{K5_Indigo}{HTML}{2b0c81}\n\definecolor{K5_Blue}{HTML}{539df7}\n\definecolor{K5_Red}{HTML}{ff2500}\n\definecolor{K5_Black}{HTML}{000000}\n\definecolor{K5_White}{HTML}{ffffff}\n\n\begin{document}\n    \begin{tikzpicture}\n        % Board Background\n        \fill[K5_Black] (0,0) rectangle (4,2);\n        \draw[K5_Indigo, line width=2pt] (0,0) rectangle (4,2);\n        \n        % Dividers\n        \draw[K5_White!30] (2,0.2) -- (2,1.8);\n        \n        % Team Labels\n        \node[text=K5_White, font=\sffamily\tiny\bfseries] at (1, 1.6) {TEAM A};\n        \node[text=K5_White, font=\sffamily\tiny\bfseries] at (3, 1.6) {TEAM B};\n        \n        % Scores\n        \node[text=K5_Blue, font=\sffamily\LARGE\bfseries] at (1, 0.9) {$286$};\n        \node[text=K5_Red, font=\sffamily\LARGE\bfseries] at (3, 0.9) {$354$};\n        \n        % Logic Tags\n        \node[anchor=west, text=K5_Blue, font=\sffamily\tiny\bfseries, draw=K5_Blue, rounded corners=1pt] at (4.2, 1.3) {TOTAL (+)};\n        \node[anchor=west, text=K5_Red, font=\sffamily\tiny\bfseries, draw=K5_Red, rounded corners=1pt] at (4.2, 0.7) {GAP ($-$ )};\n    \end{tikzpicture}\n\end{document}",image="https://d37a7zdiv6xmqa.cloudfront.net/media/MatchList-Sample-3_10003.png",width=280,height=145]::
- [id=697480dde95132000173a480][_id=822bfaea-5f07-4744-8658-e9cc8ca58f74] 4
- [id=697480dde95132000173a481][_id=aa1e03e1-1d6c-47e0-b4a2-72d8fd946381] 5
- [id=697480dde95132000173a482][_id=a4923978-3c75-44a1-9f7b-89aaee5af5d9] <br>
| R1C1 | R1C2 | R1C3 |
|------|------|------|
| R2C1 | R2C2 | R2C3 |
:::

::: classification-mapping
1: 1
2: 2
3: 3
153a445a-969a-450d-b8f0-75b4ffe3e2f8: aa1e03e1-1d6c-47e0-b4a2-72d8fd946381
4ec6f8fb-efd0-4666-96ba-5959cb1d97f9: aa1e03e1-1d6c-47e0-b4a2-72d8fd946381
c77b83be-5567-4f64-97b8-f1f9b1cc6f15: a4923978-3c75-44a1-9f7b-89aaee5af5d9
:::

::: solution
Here we keep a detailed Step by Step Solution with proper spacing with line and paragraph breaks.<br>
We make use of Latex rendered visuals.<br>
We use 1 column layout<br>
We use formatting options<br>
We keep all math (numbers, equations, fractions, formulas etc) in latex
:::

::: hint
Here we keep a simple 2 liner with proper spacing with line and paragraph breaks.<br>
We use 1 column layout<br>
We use formatting options<br>
We keep all math (numbers, equations, fractions, formulas etc) in latex
:::
