::: question
ID: Q-TOKEN-001
Type: Token Highlight
::: stem
# Highlight the nouns
Select all the nouns in the sentence below.
::: token-config
Token Type: word
::: token-text
The cat sat on the mat.
:::
