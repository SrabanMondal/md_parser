::: question
ID: 12
QuestionID: MCQ-Sample
Type: MCQ
Tags: Tag 1, Tag 2
:::

::: mcq-config
Orientation: horizontal
MCQ Type: default
:::

::: stem
This is an MCQ with options aligned Horizontal. Below this line the Question stem is in 2 column Layout.<br>

::: columns [70%, 30%]
This is the part of the Question Stem in the Left column which has$70 %$% width.<br>
$70$is written in Latex. All numbers, formulas, units, expression, math will all be written in Latex with proper formatting like Fraction $\frac{a}{b}$ is incorrect while $\dfrac{a}{b}$ is correct.<br>
<br>
* ** **This entire sentence is in bold** **

* ** ***This entire sentence is in bold and italics*** **<br>
<br>
This is a table with 2 rows and 3 columns:<br>

| R1C1 | R1C2 | R1C3 |
|------|------|------|
| R2C1 | R2C2 | R2C3 |

<br>
Below is an image: 

![This is the Alt Text for US NG G7 L2 image 026](https://d2lhxh95t9lwdp.cloudfront.net/US_NG_G7_L2_image_026)

<br>
=== COL
This is the right column content.<br>
Below is a Latex Rendered Visual in the right column.

```latex[image="https://d37a7zdiv6xmqa.cloudfront.net/media/MCQ-Sample_10005.png",width=332,height=161]
\documentclass[tikz, border=10pt]{standalone}
\usepackage{fontspec}
\setmainfont{Latin Modern Roman}
\usepackage{tikz}
\usetikzlibrary{shapes.symbols, positioning}
\usepackage{xcolor}
\usepackage{bm}

\definecolor{K5_Indigo}{HTML}{2b0c81}
\definecolor{K5_Blue}{HTML}{539df7}
\definecolor{K5_Red}{HTML}{ff2500}
\definecolor{K5_Black}{HTML}{000000}
\definecolor{K5_White}{HTML}{ffffff}

\begin{document}
    \begin{tikzpicture}
        % Board Background
        \fill[K5_Black] (0,0) rectangle (4,2);
        \draw[K5_Indigo, line width=2pt] (0,0) rectangle (4,2);
        
        % Dividers
        \draw[K5_White!30] (2,0.2) -- (2,1.8);
        
        % Team Labels
        \node[text=K5_White, font=\sffamily\tiny\bfseries] at (1, 1.6) {TEAM A};
        \node[text=K5_White, font=\sffamily\tiny\bfseries] at (3, 1.6) {TEAM B};
        
        % Scores
        \node[text=K5_Blue, font=\sffamily\LARGE\bfseries] at (1, 0.9) {$286$};
        \node[text=K5_Red, font=\sffamily\LARGE\bfseries] at (3, 0.9) {$354$};
        
        % Logic Tags
        \node[anchor=west, text=K5_Blue, font=\sffamily\tiny\bfseries, draw=K5_Blue, rounded corners=1pt] at (4.2, 1.3) {TOTAL (+)};
        \node[anchor=west, text=K5_Red, font=\sffamily\tiny\bfseries, draw=K5_Red, rounded corners=1pt] at (4.2, 0.7) {GAP ($-$ )};
    \end{tikzpicture}
\end{document}
```
:::

<br>
:::

::: options 
::: option id=6968a07732a1cf00014149a6
This is option 1 with number written in Latex $\dfrac{a}{b}$. It is Incorrect
:::
::: option id=6968a07732a1cf00014149a7 [correct]
This is Option 2 which has an image. It is Correct option<br>
<br>
![This is alt text for US NG G7 L2 image 026](https://d2lhxh95t9lwdp.cloudfront.net/US_NG_G7_L2_image_026)
:::
::: option id=6968a07732a1cf00014149a8 [correct]
This is option 3 with latex rendered visual. This is also correct<br>
<br>
```latex[image="https://d37a7zdiv6xmqa.cloudfront.net/media/MCQ-Horizontal-Sample_10002.png",width=257,height=115]
\documentclass[tikz, border=10pt]{standalone}
\usepackage{fontspec}
\setmainfont{Latin Modern Roman}
\usepackage{tikz}
\usetikzlibrary{shapes.symbols, positioning}
\usepackage{xcolor}
\usepackage{bm}

\definecolor{K5_Indigo}{HTML}{2b0c81}
\definecolor{K5_Blue}{HTML}{539df7}
\definecolor{K5_Red}{HTML}{ff2500}
\definecolor{K5_Black}{HTML}{000000}
\definecolor{K5_White}{HTML}{ffffff}

\begin{document}
    \begin{tikzpicture}
        % Board Background
        \fill[K5_Black] (0,0) rectangle (4,2);
        \draw[K5_Indigo, line width=2pt] (0,0) rectangle (4,2);
        
        % Dividers
        \draw[K5_White!30] (2,0.2) -- (2,1.8);
        
        % Team Labels
        \node[text=K5_White, font=\sffamily\tiny\bfseries] at (1, 1.6) {TEAM A};
        \node[text=K5_White, font=\sffamily\tiny\bfseries] at (3, 1.6) {TEAM B};
        
        % Scores
        \node[text=K5_Blue, font=\sffamily\LARGE\bfseries] at (1, 0.9) {$286$};
        \node[text=K5_Red, font=\sffamily\LARGE\bfseries] at (3, 0.9) {$354$};
        
        % Logic Tags
        \node[anchor=west, text=K5_Blue, font=\sffamily\tiny\bfseries, draw=K5_Blue, rounded corners=1pt] at (4.2, 1.3) {TOTAL (+)};
        \node[anchor=west, text=K5_Red, font=\sffamily\tiny\bfseries, draw=K5_Red, rounded corners=1pt] at (4.2, 0.7) {GAP ($-$ )};
    \end{tikzpicture}
\end{document}
```
:::
::: option id=6968a07732a1cf00014149a9
This is option 4. Incorrect
:::
:::

::: solution
Here we keep a detailed Step by Step Solution with proper spacing with line and paragraph breaks.<br>
We make use of Latex rendered visuals.<br>
* **We use 1 column layout**<br>
We use formatting options<br>
We keep all math (numbers, equations, fractions, formulas etc) in latex<br>
:::

::: hint
Here we keep a simple 2 liner with proper spacing with line and paragraph breaks.<br>
We use 1 column layout<br>
We use formatting options<br>
We keep all math (numbers, equations, fractions, formulas etc) in latex
:::
